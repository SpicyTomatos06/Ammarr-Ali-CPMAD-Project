import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../services/firestore_service.dart';

class AddRecordPage extends StatefulWidget {
  const AddRecordPage({super.key});

  @override
  _AddRecordPageState createState() => _AddRecordPageState();
}

class _AddRecordPageState extends State<AddRecordPage> {
  String? bookAuthor;
  String? bookTitle;
  String? bookDescription;

  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Saving Book Record'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: formKey,
            child: Column(
              children: [
                TextFormField(
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(labelText: 'Author Name'),
                  validator: (val) =>
                      val!.isEmpty ? 'Enter Book Author' : null,
                  onSaved: (val) => bookAuthor = val,
                ),
                TextFormField(
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(labelText: 'Book Title'),
                  validator: (val) =>
                      val!.isEmpty ? 'Enter Book Title' : null,
                  onSaved: (val) => bookTitle = val,
                ),
                TextFormField(
                  keyboardType: TextInputType.text,
                  decoration:
                      const InputDecoration(labelText: 'Book Description'),
                  validator: (val) =>
                      val!.isEmpty ? 'Enter Book Description' : null,
                  onSaved: (val) => bookDescription = val,
                ),
                Container(
                  margin: const EdgeInsets.only(top: 10.0),
                  child: ElevatedButton(
                    onPressed: _submit,
                    child: const Text('Save Book Record'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submit() {
    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();
    } else {
      return;
    }

    FirestoreService().addBookData(
      bookAuthor!,
      bookTitle!,
      bookDescription!,
    );

    Fluttertoast.showToast(
      msg: 'Data saved successfully',
      gravity: ToastGravity.TOP,
    );
  }
}
