import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../model/book.dart';

class FirestoreService {
  // Create a CollectionReference called bookCollection that references
  // the firestore collection
  final CollectionReference bookCollection =
      FirebaseFirestore.instance.collection('books');

  // Add book
  Future<void> addBookData(
      String bookAuthor, String bookTitle, String bookDescription) async {
    var docRef = bookCollection.doc();
    debugPrint('add docRef: ${docRef.id}');

    await bookCollection.doc(docRef.id).set({
      'uid': docRef.id,
      'author': bookAuthor,
      'title': bookTitle,
      'description': bookDescription,
    });
  }

  // Read books
  Future<List<Book>> readBookData() async {
    List<Book> bookList = [];

    QuerySnapshot snapshot = await bookCollection.get();
    for (var document in snapshot.docs) {
      Book book =
          Book.fromMap(document.data() as Map<String, dynamic>);
      bookList.add(book);
    }

    debugPrint('Booklist: $bookList');
    return bookList;
  }

  // Delete single book by document ID
  Future<void> deleteBookData(String docId) async {
    await bookCollection.doc(docId).delete();
    debugPrint('deleting uid: $docId');
  }

  // Update book (reference example)
  Future<void> updateBookData(String docId, String bookAuthor,
      String bookTitle, String bookDescription) async {
    debugPrint('update docRef: $docId');

    await bookCollection.doc(docId).update({
      'author': bookAuthor,
      'title': bookTitle,
      'description': bookDescription,
    });
  }

  // Delete all book documents (reference example)
  Future<void> deleteBookDoc() async {
    QuerySnapshot snapshot = await bookCollection.get();
    for (DocumentSnapshot ds in snapshot.docs) {
      await ds.reference.delete();
    }
  }
}
